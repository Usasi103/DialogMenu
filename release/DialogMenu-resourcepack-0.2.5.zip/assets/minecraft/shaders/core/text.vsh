#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void dm_previous_main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}

// Called after the vanilla 26.3 text shader.
layout(location = 4) flat out int dmLocal;
layout(location = 5) out vec2 dmCanvas;
layout(location = 6) out vec3 dmView;
layout(location = 7) out vec2 dmTexel;
uniform sampler2D Sampler0;
#include <minecraft:globals.glsl>

void dm_local_vertex() {
    dmLocal = 0;
    dmCanvas = vec2(0.0);
    dmView = vec3(0.0);
    dmTexel = vec2(0.0);
#if !defined(IS_GUI) && !defined(IS_GRAYSCALE)
    if (all(equal(ivec3(round(Color.rgb * 255.0)), ivec3(253, 23, 171)))) {
        // Atlas UVs carry the actual corner. Vertex indices can be reordered by batching.
        ivec2 size = textureSize(Sampler0, 0);
        ivec2 texel = clamp(ivec2(UV0 * size), ivec2(0), size - 1);
        ivec3 tag = ivec3(round(texelFetch(Sampler0, texel, 0).rgb * 255.0));
        const vec2 grid = vec2(8.0, 5.0);
        const vec2 tileSize = vec2(240.0, 216.0);
        const int border = 2;
        int tile = tag.r - 32;
        if (tile < 0 || tile >= int(grid.x * grid.y) || (tag.g != 31 && tag.g != 223) || (tag.b != 31 && tag.b != 223)) return;
        vec2 corner = vec2(tag.gb - ivec2(127)) / 96.0;
        vec2 fraction = vec2(corner.x + 1.0, 1.0 - corner.y) * 0.5;
        vec2 origin = vec2(texel) - fraction * (tileSize + float(2 * border - 1));
        dmTexel = origin + float(border) + fraction * tileSize;
        dmLocal = 1;
        vec2 cell = vec2(tile % int(grid.x), tile / int(grid.x));
        vec2 screen = (cell + fraction) / grid;
        dmCanvas = vec2(screen.x * 320.0 - 160.0, 90.0 - screen.y * 180.0);
        dmView = (ModelViewMat * vec4(Position, 1.0)).xyz;
        // 26.3 uses reversed depth: 1 is nearest. The normal text pass writes depth.
        gl_Position = vec4(dmCanvas / vec2(160.0, 90.0), 1.0, 1.0);
        vertexColor = vec4(1.0);
    }
#endif
}

// Public menu typography. Only explicit negative-X bands in orthographic GUI text opt in.
// Runs after the vanilla text and fullscreen hooks; world text and HUD coordinates pass through.
void dm_native_cjk_vertex() {
#ifdef IS_GUI
    if (ProjMat[3][3] < 0.5) return;
    int band = int(floor((-Position.x + 8192.0) / 16384.0));
    if (band < 200 || band >= 276) return;
    int encoded = band - 200;
    bool italic = encoded >= 38;
    int typography = encoded % 38;
    int size = typography / 2 + 6;
    bool raised = (typography % 2) != 0;
    float paddedHeight = float((size * 3 + 1) / 2);
    float scale = paddedHeight / 12.0;
    float ascent = size == 8 ? 11.0
        : raised && size <= 12 ? float(7 - (18 - size) / 2) : float(min(7, size));
#ifdef VULKAN
    int corner = gl_VertexIndex % 4;
#else
    int corner = gl_VertexID % 4;
#endif
    // Vanilla BakedSheetGlyph emits top-left, bottom-left, bottom-right, top-right.
    vec2 local = vec2(corner >= 2 ? 8.0 : 0.0, corner == 1 || corner == 2 ? 8.0 : 0.0);
    vec3 position = Position;
    position.x += float(band * 16384) + local.x * (scale - 1.0);
    position.y += 7.0 - ascent + local.y * (scale - 1.0);
    if (italic) position.x += 1.0 - 0.25 * (7.0 - ascent + local.y / 8.0 * paddedHeight);
    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);
#endif
}

void main() { dm_previous_main(); dm_local_vertex(); dm_native_cjk_vertex(); }
